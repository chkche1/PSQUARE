package com.sshannin.pp.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionManager {
	private DBConnectionManager(){}
	
	private static Connection connection;
	
	static{
		startConnection();
	}
	
	public static synchronized int executeUpdate(String str){
		try {
		Statement st = connection.createStatement();	
			return st.executeUpdate(str);
		} catch (SQLException e) {
			System.err.println("Error when executing statement: '" + str + "'.");
			System.err.println(e.getMessage());
			e.printStackTrace();
			return 0;
		}
	}
	
	public static synchronized ResultSet executeStatement(String str){
		try {
		Statement st = connection.createStatement();	
			st.execute(str);
			return st.getResultSet();
		} catch (SQLException e) {
			System.err.println("Error when executing statement: '" + str + "'.");
			System.err.println(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	private static void startConnection(){
		final String serverName = "fling.seas.upenn.edu";
		final String database = "sshannin";
		final String user = "sshannin";
		final String passwd = "lmaonaise";
		final String url = "jdbc:mysql://" + serverName + "/" + database;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(url, user, passwd);
		} catch (SQLException e) {
			System.out.println("ERROR CONNECTING TO DB");
			System.out.println(e.getMessage());
			e.printStackTrace();
			System.exit(1);
		} catch (ClassNotFoundException e) {
			System.out.println("Couldn't find driver class");
			e.printStackTrace();
		}
	}
	

}
