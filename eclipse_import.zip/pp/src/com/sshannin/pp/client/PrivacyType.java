package com.sshannin.pp.client;

public enum PrivacyType {
	ALL, CUSTOM;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		if (this == ALL)
			return "ALL";
		else
			return "CUSTOM";
	}

}
