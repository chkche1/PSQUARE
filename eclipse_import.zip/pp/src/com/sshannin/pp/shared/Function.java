package com.sshannin.pp.shared;

public abstract class Function {
	
	public abstract void run();

}
