package com.sshannin.pp.shared;

public class Pair<P, Q> {
	public final P p;

	public final Q q;

	public Pair(P _p, Q _q) {
		p = _p;
		q = _q;
	}

}
