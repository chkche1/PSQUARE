
#USERS
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22000','Ana','Vladan',null,'Ana@email.com','F','40 Powelton Avenue, Philadelphia, PA','password0'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22001','Arielle','Farner',null,'Arielle@email.com','F','1330 Market Street, New York, NY','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22002','Matt','Carey',null,'Matt@email.com','M','1700 Walnut Street, Jersey City, NJ','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22003','Rob','Marco',null,'Rob@email.com','F','2525 Locust Street, Reston, VA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22004','Nate','Dupret',null,'Nate@email.com','M','4120 Spruce Street, Pittsburg, PA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22005','Aditya','Minocha',null,'Aditya@email.com','M','3930 Pine Street, San Francisco, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22006','Brinda','Desai',null,'Brinda@email.com','F','4100 Baltimore Avenue, San Diego, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22007','Anand','Thakkar',null,'Anand@email.com','M','4200 Chester Avenue, Santa Barbara, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22008','Bhavik','Shah',null,'Bhavik@email.com','M','1313 Levine Hall, Los Angeles, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22009','Vishal','Patel',null,'Vishal@email.com','M','543 Lincoln Drive,Seattle, WA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22010','Xao','Lee',null,'Xao@email.com','M','389 WestDrive, Philadelphia, PA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22011','Yao','Ming',null,'Yao@email.com','M','4545 Baltimore Avenue, New York, NY','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22012','Xing','Chen',null,'Xing@email.com','F','159 Westlakes Drive, Jersey City, NJ','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22013','Ming','Wang',null,'Ming@email.com','F','334 Southpoint Drive, Reston, VA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22014','Chao','Lau',null,'Chao@email.com','M','1990 Woodland Avenue, Pittsburg, PA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22015','Akshay','Kumar',null,'Akshay@email.com','M','4356 Pointe Circle, San Francisco, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22016','Hrithik','Roshan',null,'Hrithik@email.com','M','43 Pine Arms Avenue, San Diego, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22017','Aishwarya','Rai',null,'Aishwarya@email.com','M','1799 Market Street, Santa Barbara, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22018','Katrina','Kaif',null,'Katrina@email.com','F','142 Spruce Street, Los Angeles, CA','password'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('22019','Salman','Khan',null,'Salman@email.com','M','1500 Walnut Street, Seattle, WA ','password'); 

#PROFESSORS
insert into Professor(userid, research_area, room_id) values  ('22000','Database','GRW 316'); 
insert into Professor(userid, research_area, room_id) values  ('22001','Algorithm','LMR 12'); 
insert into Professor(userid, research_area, room_id) values  ('22002','Machine Learning','LEV 445'); 
insert into Professor(userid, research_area, room_id) values  ('22003','Robotics','LEV 45'); 
insert into Professor(userid, research_area, room_id) values  ('22004','Wireless Networks','VAN 12'); 
insert into Professor(userid, research_area, room_id) values  ('22010','TOC','BRB 90'); 
insert into Professor(userid, research_area, room_id) values  ('22011','Chemical','KLI 234'); 
insert into Professor(userid, research_area, room_id) values  ('22012','Mathematics','GRW 456'); 
insert into Professor(userid, research_area, room_id) values  ('22013','Software Systems','MKR 65'); 
insert into Professor(userid, research_area, room_id) values  ('22014','AI','FGR 123'); 

#STUDENTS
insert into Student(userid, advisorid, year) values  ('22005','22000','5'); 
insert into Student(userid, advisorid, year) values  ('22006','22001','4'); 
insert into Student(userid, advisorid, year) values  ('22007','22002','2'); 
insert into Student(userid, advisorid, year) values  ('22008','22003','2'); 
insert into Student(userid, advisorid, year) values  ('22009','22004','3'); 
insert into Student(userid, advisorid, year) values  ('22010','22011','4'); 
insert into Student(userid, advisorid, year) values  ('22012','22013','3'); 
insert into Student(userid, advisorid, year) values  ('22014','22013','2'); 

#CIRCLES
insert into Circle(cid, userid, name) values  ('22000','22000','University'); 
insert into Circle(cid, userid, name) values  ('22001','22000','University'); 
insert into Circle(cid, userid, name) values  ('22002','22000','Neighbors'); 
insert into Circle(cid, userid, name) values  ('22003','22001','University'); 
insert into Circle(cid, userid, name) values  ('22004','22001','University'); 
insert into Circle(cid, userid, name) values  ('22005','22001','Neighbors'); 
insert into Circle(cid, userid, name) values  ('22006','22002','University'); 
insert into Circle(cid, userid, name) values  ('22007','22002','University'); 
insert into Circle(cid, userid, name) values  ('22008','22002','Neighbors'); 
insert into Circle(cid, userid, name) values  ('22009','22003','University'); 
insert into Circle(cid, userid, name) values  ('22010','22003','University'); 
insert into Circle(cid, userid, name) values  ('22011','22003','Neighbors'); 
insert into Circle(cid, userid, name) values  ('22012','22004','University'); 
insert into Circle(cid, userid, name) values  ('22013','22004','University'); 
insert into Circle(cid, userid, name) values  ('22014','22004','Neighbors'); 
insert into Circle(cid, userid, name) values  ('22015','22005','default_22005'); 
insert into Circle(cid, userid, name) values  ('22016','22005','family'); 
insert into Circle(cid, userid, name) values  ('22017','22005','students'); 
insert into Circle(cid, userid, name) values  ('22018','22006','default_22006'); 
insert into Circle(cid, userid, name) values  ('22019','22006','upenn'); 
insert into Circle(cid, userid, name) values  ('22020','22006','neighbors'); 
insert into Circle(cid, userid, name) values  ('22021','22007','default_22007'); 
insert into Circle(cid, userid, name) values  ('22022','22007','friends'); 
insert into Circle(cid, userid, name) values  ('22023','22007','neighbors'); 
insert into Circle(cid, userid, name) values  ('22024','22008','default_22008'); 
insert into Circle(cid, userid, name) values  ('22025','22008','relations'); 
insert into Circle(cid, userid, name) values  ('22026','22008','friends'); 
insert into Circle(cid, userid, name) values  ('22027','22009','default_22009'); 
insert into Circle(cid, userid, name) values  ('22028','22009','town'); 
insert into Circle(cid, userid, name) values  ('22029','22009','family'); 
insert into Circle(cid, userid, name) values  ('22031','22010','default_22010'); 
insert into Circle(cid, userid, name) values  ('22032','22010','collegues'); 
insert into Circle(cid, userid, name) values  ('22033','22010','mit'); 
insert into Circle(cid, userid, name) values  ('22034','22011','default_22011'); 
insert into Circle(cid, userid, name) values  ('22035','22011','upenn'); 
insert into Circle(cid, userid, name) values  ('22036','22011','friends'); 
insert into Circle(cid, userid, name) values  ('22037','22012','default_22012'); 
insert into Circle(cid, userid, name) values  ('22038','22012','relations'); 
insert into Circle(cid, userid, name) values  ('22039','22012','university'); 
insert into Circle(cid, userid, name) values  ('22040','22013','default_22013'); 
insert into Circle(cid, userid, name) values  ('22041','22013','school'); 
insert into Circle(cid, userid, name) values  ('22042','22013','neighbors'); 
insert into Circle(cid, userid, name) values  ('22043','22014','default_22014'); 
insert into Circle(cid, userid, name) values  ('22044','22014','friends'); 
insert into Circle(cid, userid, name) values  ('22045','22014','collegues'); 
insert into Circle(cid, userid, name) values  ('22046','22015','default_22015'); 
insert into Circle(cid, userid, name) values  ('22047','22015','friends'); 
insert into Circle(cid, userid, name) values  ('22048','22016','default_22016'); 
insert into Circle(cid, userid, name) values  ('22049','22016','stars'); 
insert into Circle(cid, userid, name) values  ('22050','22017','default_22017'); 
insert into Circle(cid, userid, name) values  ('22051','22017','neighbors'); 
insert into Circle(cid, userid, name) values  ('22052','22018','default_22018'); 
insert into Circle(cid, userid, name) values  ('22053','22018','collegues'); 
insert into Circle(cid, userid, name) values  ('22054','22019','default_22019'); 
insert into Circle(cid, userid, name) values  ('22055','22019','friends'); 

#FRIENDS
insert into FriendRelation(friendid, cid) values  ('22001','22000'); 
insert into FriendRelation(friendid, cid) values  ('22002','22000'); 
insert into FriendRelation(friendid, cid) values  ('22003','22000'); 
insert into FriendRelation(friendid, cid) values  ('22004','22000'); 
insert into FriendRelation(friendid, cid) values  ('22001','22001'); 
insert into FriendRelation(friendid, cid) values  ('22002','22001'); 
insert into FriendRelation(friendid, cid) values  ('22003','22002'); 
insert into FriendRelation(friendid, cid) values  ('22004','22002'); 
insert into FriendRelation(friendid, cid) values  ('22000','22003'); 
insert into FriendRelation(friendid, cid) values  ('22002','22003'); 
insert into FriendRelation(friendid, cid) values  ('22003','22003'); 
insert into FriendRelation(friendid, cid) values  ('22004','22003'); 
insert into FriendRelation(friendid, cid) values  ('22000','22004'); 
insert into FriendRelation(friendid, cid) values  ('22002','22004'); 
insert into FriendRelation(friendid, cid) values  ('22003','22005'); 
insert into FriendRelation(friendid, cid) values  ('22004','22005'); 
insert into FriendRelation(friendid, cid) values  ('22001','22006'); 
insert into FriendRelation(friendid, cid) values  ('22000','22006'); 
insert into FriendRelation(friendid, cid) values  ('22003','22006'); 
insert into FriendRelation(friendid, cid) values  ('22004','22006'); 
insert into FriendRelation(friendid, cid) values  ('22000','22007'); 
insert into FriendRelation(friendid, cid) values  ('22001','22007'); 
insert into FriendRelation(friendid, cid) values  ('22003','22008'); 
insert into FriendRelation(friendid, cid) values  ('22004','22008'); 
insert into FriendRelation(friendid, cid) values  ('22001','22009'); 
insert into FriendRelation(friendid, cid) values  ('22002','22009'); 
insert into FriendRelation(friendid, cid) values  ('22000','22009'); 
insert into FriendRelation(friendid, cid) values  ('22004','22009'); 
insert into FriendRelation(friendid, cid) values  ('22001','22010'); 
insert into FriendRelation(friendid, cid) values  ('22002','22010'); 
insert into FriendRelation(friendid, cid) values  ('22000','22011'); 
insert into FriendRelation(friendid, cid) values  ('22004','22011'); 
insert into FriendRelation(friendid, cid) values  ('22001','22012'); 
insert into FriendRelation(friendid, cid) values  ('22002','22012'); 
insert into FriendRelation(friendid, cid) values  ('22003','22012'); 
insert into FriendRelation(friendid, cid) values  ('22000','22012'); 
insert into FriendRelation(friendid, cid) values  ('22001','22013'); 
insert into FriendRelation(friendid, cid) values  ('22002','22013'); 
insert into FriendRelation(friendid, cid) values  ('22003','22014'); 
insert into FriendRelation(friendid, cid) values  ('22000','22014'); 
insert into FriendRelation(friendid, cid) values  ('22005','22014'); 
insert into FriendRelation(friendid, cid) values  ('22006','22015'); 
insert into FriendRelation(friendid, cid) values  ('22007','22015'); 
insert into FriendRelation(friendid, cid) values  ('22008','22015'); 
insert into FriendRelation(friendid, cid) values  ('22009','22015'); 
insert into FriendRelation(friendid, cid) values  ('22004','22015'); 
insert into FriendRelation(friendid, cid) values  ('22006','22016'); 
insert into FriendRelation(friendid, cid) values  ('22007','22016'); 
insert into FriendRelation(friendid, cid) values  ('22004','22016'); 
insert into FriendRelation(friendid, cid) values  ('22008','22017'); 
insert into FriendRelation(friendid, cid) values  ('22009','22017'); 
insert into FriendRelation(friendid, cid) values  ('22005','22018'); 
insert into FriendRelation(friendid, cid) values  ('22007','22018'); 
insert into FriendRelation(friendid, cid) values  ('22008','22018'); 
insert into FriendRelation(friendid, cid) values  ('22009','22018'); 
insert into FriendRelation(friendid, cid) values  ('22005','22019'); 
insert into FriendRelation(friendid, cid) values  ('22007','22019'); 
insert into FriendRelation(friendid, cid) values  ('22008','22020'); 
insert into FriendRelation(friendid, cid) values  ('22009','22020'); 
insert into FriendRelation(friendid, cid) values  ('22006','22021'); 
insert into FriendRelation(friendid, cid) values  ('22005','22021'); 
insert into FriendRelation(friendid, cid) values  ('22008','22021'); 
insert into FriendRelation(friendid, cid) values  ('22009','22021'); 
insert into FriendRelation(friendid, cid) values  ('22006','22022'); 
insert into FriendRelation(friendid, cid) values  ('22005','22022'); 
insert into FriendRelation(friendid, cid) values  ('22008','22023'); 
insert into FriendRelation(friendid, cid) values  ('22009','22023'); 
insert into FriendRelation(friendid, cid) values  ('22006','22024'); 
insert into FriendRelation(friendid, cid) values  ('22007','22024'); 
insert into FriendRelation(friendid, cid) values  ('22005','22024'); 
insert into FriendRelation(friendid, cid) values  ('22009','22024'); 
insert into FriendRelation(friendid, cid) values  ('22006','22025'); 
insert into FriendRelation(friendid, cid) values  ('22007','22025'); 
insert into FriendRelation(friendid, cid) values  ('22005','22026'); 
insert into FriendRelation(friendid, cid) values  ('22009','22026'); 
insert into FriendRelation(friendid, cid) values  ('22006','22027'); 
insert into FriendRelation(friendid, cid) values  ('22007','22027'); 
insert into FriendRelation(friendid, cid) values  ('22008','22027'); 
insert into FriendRelation(friendid, cid) values  ('22005','22027'); 
insert into FriendRelation(friendid, cid) values  ('22010','22027'); 
insert into FriendRelation(friendid, cid) values  ('22006','22028'); 
insert into FriendRelation(friendid, cid) values  ('22007','22028'); 
insert into FriendRelation(friendid, cid) values  ('22008','22029'); 
insert into FriendRelation(friendid, cid) values  ('22005','22029'); 
insert into FriendRelation(friendid, cid) values  ('22010','22029'); 
insert into FriendRelation(friendid, cid) values  ('22011','22031'); 
insert into FriendRelation(friendid, cid) values  ('22012','22031'); 
insert into FriendRelation(friendid, cid) values  ('22013','22031'); 
insert into FriendRelation(friendid, cid) values  ('22014','22031'); 
insert into FriendRelation(friendid, cid) values  ('22009','22031'); 
insert into FriendRelation(friendid, cid) values  ('22011','22032'); 
insert into FriendRelation(friendid, cid) values  ('22012','22032'); 
insert into FriendRelation(friendid, cid) values  ('22013','22033'); 
insert into FriendRelation(friendid, cid) values  ('22014','22033'); 
insert into FriendRelation(friendid, cid) values  ('22010','22034'); 
insert into FriendRelation(friendid, cid) values  ('22012','22034'); 
insert into FriendRelation(friendid, cid) values  ('22013','22034'); 
insert into FriendRelation(friendid, cid) values  ('22014','22034'); 
insert into FriendRelation(friendid, cid) values  ('22010','22035'); 
insert into FriendRelation(friendid, cid) values  ('22012','22035'); 
insert into FriendRelation(friendid, cid) values  ('22013','22036'); 
insert into FriendRelation(friendid, cid) values  ('22014','22036'); 
insert into FriendRelation(friendid, cid) values  ('22011','22037'); 
insert into FriendRelation(friendid, cid) values  ('22010','22037'); 
insert into FriendRelation(friendid, cid) values  ('22013','22037'); 
insert into FriendRelation(friendid, cid) values  ('22014','22037'); 
insert into FriendRelation(friendid, cid) values  ('22011','22038'); 
insert into FriendRelation(friendid, cid) values  ('22010','22038'); 
insert into FriendRelation(friendid, cid) values  ('22013','22039'); 
insert into FriendRelation(friendid, cid) values  ('22014','22039'); 
insert into FriendRelation(friendid, cid) values  ('22011','22040'); 
insert into FriendRelation(friendid, cid) values  ('22012','22040'); 
insert into FriendRelation(friendid, cid) values  ('22010','22040'); 
insert into FriendRelation(friendid, cid) values  ('22014','22040'); 
insert into FriendRelation(friendid, cid) values  ('22011','22041'); 
insert into FriendRelation(friendid, cid) values  ('22012','22041'); 
insert into FriendRelation(friendid, cid) values  ('22010','22042'); 
insert into FriendRelation(friendid, cid) values  ('22014','22042'); 
insert into FriendRelation(friendid, cid) values  ('22011','22043'); 
insert into FriendRelation(friendid, cid) values  ('22012','22043'); 
insert into FriendRelation(friendid, cid) values  ('22013','22043'); 
insert into FriendRelation(friendid, cid) values  ('22010','22043'); 
insert into FriendRelation(friendid, cid) values  ('22015','22043'); 
insert into FriendRelation(friendid, cid) values  ('22011','22044'); 
insert into FriendRelation(friendid, cid) values  ('22012','22044'); 
insert into FriendRelation(friendid, cid) values  ('22015','22044'); 
insert into FriendRelation(friendid, cid) values  ('22013','22045'); 
insert into FriendRelation(friendid, cid) values  ('22010','22045'); 
insert into FriendRelation(friendid, cid) values  ('22016','22046'); 
insert into FriendRelation(friendid, cid) values  ('22017','22046'); 
insert into FriendRelation(friendid, cid) values  ('22018','22046'); 
insert into FriendRelation(friendid, cid) values  ('22019','22046'); 
insert into FriendRelation(friendid, cid) values  ('22014','22046'); 
insert into FriendRelation(friendid, cid) values  ('22016','22047'); 
insert into FriendRelation(friendid, cid) values  ('22017','22047'); 
insert into FriendRelation(friendid, cid) values  ('22018','22047'); 
insert into FriendRelation(friendid, cid) values  ('22014','22047'); 
insert into FriendRelation(friendid, cid) values  ('22015','22048'); 
insert into FriendRelation(friendid, cid) values  ('22017','22048'); 
insert into FriendRelation(friendid, cid) values  ('22018','22048'); 
insert into FriendRelation(friendid, cid) values  ('22019','22048'); 
insert into FriendRelation(friendid, cid) values  ('22015','22049'); 
insert into FriendRelation(friendid, cid) values  ('22017','22049'); 
insert into FriendRelation(friendid, cid) values  ('22018','22049'); 
insert into FriendRelation(friendid, cid) values  ('22016','22050'); 
insert into FriendRelation(friendid, cid) values  ('22015','22050'); 
insert into FriendRelation(friendid, cid) values  ('22018','22050'); 
insert into FriendRelation(friendid, cid) values  ('22019','22050'); 
insert into FriendRelation(friendid, cid) values  ('22016','22051'); 
insert into FriendRelation(friendid, cid) values  ('22015','22051'); 
insert into FriendRelation(friendid, cid) values  ('22018','22051'); 
insert into FriendRelation(friendid, cid) values  ('22016','22052'); 
insert into FriendRelation(friendid, cid) values  ('22017','22052'); 
insert into FriendRelation(friendid, cid) values  ('22015','22052'); 
insert into FriendRelation(friendid, cid) values  ('22019','22052'); 
insert into FriendRelation(friendid, cid) values  ('22016','22053'); 
insert into FriendRelation(friendid, cid) values  ('22017','22053'); 
insert into FriendRelation(friendid, cid) values  ('22015','22053'); 
insert into FriendRelation(friendid, cid) values  ('22016','22054'); 
insert into FriendRelation(friendid, cid) values  ('22017','22054'); 
insert into FriendRelation(friendid, cid) values  ('22018','22054'); 
insert into FriendRelation(friendid, cid) values  ('22015','22054'); 
insert into FriendRelation(friendid, cid) values  ('22016','22055'); 
insert into FriendRelation(friendid, cid) values  ('22017','22055'); 
insert into FriendRelation(friendid, cid) values  ('22018','22055'); 

#INTERESTS
insert into Interest(userid, interest) values  ('22000','chess'); 
insert into Interest(userid, interest) values  ('22000','soccer'); 
insert into Interest(userid, interest) values  ('22000','football'); 
insert into Interest(userid, interest) values  ('22001','reading'); 
insert into Interest(userid, interest) values  ('22001','surfing'); 
insert into Interest(userid, interest) values  ('22001','programming'); 
insert into Interest(userid, interest) values  ('22002','facebook'); 
insert into Interest(userid, interest) values  ('22002','algorithms'); 
insert into Interest(userid, interest) values  ('22002','cricket'); 
insert into Interest(userid, interest) values  ('22003','soccer'); 
insert into Interest(userid, interest) values  ('22003','badminton'); 
insert into Interest(userid, interest) values  ('22003','database'); 
insert into Interest(userid, interest) values  ('22004','database'); 
insert into Interest(userid, interest) values  ('22004','machine learning'); 
insert into Interest(userid, interest) values  ('22004','algorithms'); 
insert into Interest(userid, interest) values  ('22005','signal processing'); 
insert into Interest(userid, interest) values  ('22005','digital communications'); 
insert into Interest(userid, interest) values  ('22005','carrom'); 
insert into Interest(userid, interest) values  ('22006','cricket'); 
insert into Interest(userid, interest) values  ('22006','soccer'); 
insert into Interest(userid, interest) values  ('22006','reading'); 
insert into Interest(userid, interest) values  ('22007','writing'); 
insert into Interest(userid, interest) values  ('22007','facebook'); 
insert into Interest(userid, interest) values  ('22007','myspace'); 
insert into Interest(userid, interest) values  ('22008','photography'); 
insert into Interest(userid, interest) values  ('22008','soccer'); 
insert into Interest(userid, interest) values  ('22009','badminton'); 
insert into Interest(userid, interest) values  ('22010','programming'); 
insert into Interest(userid, interest) values  ('22011','facebook'); 
insert into Interest(userid, interest) values  ('22011','cricket'); 
insert into Interest(userid, interest) values  ('22011','rugby'); 
insert into Interest(userid, interest) values  ('22012','database'); 
insert into Interest(userid, interest) values  ('22012','facebook'); 
insert into Interest(userid, interest) values  ('22013','boxing'); 
insert into Interest(userid, interest) values  ('22014','poker'); 
insert into Interest(userid, interest) values  ('22015','cricket'); 
insert into Interest(userid, interest) values  ('22015','chess'); 
insert into Interest(userid, interest) values  ('22016','computer architecture'); 
insert into Interest(userid, interest) values  ('22017','algorithms'); 
insert into Interest(userid, interest) values  ('22017','database'); 
insert into Interest(userid, interest) values  ('22018','studying'); 
insert into Interest(userid, interest) values  ('22018','shopping'); 
insert into Interest(userid, interest) values  ('22019','wrestling'); 
insert into Interest(userid, interest) values  ('22019','fighting'); 
insert into Interest(userid, interest) values  ('22019','gymming'); 

#SCHOOLS
insert into AcademicInstitution(userid,institution) values  ('22000','San Diego State'); 
insert into AcademicInstitution(userid,institution) values  ('22001','PennState'); 
insert into AcademicInstitution(userid,institution) values  ('22001','PennState'); 
insert into AcademicInstitution(userid,institution) values  ('22002','MIT'); 
insert into AcademicInstitution(userid,institution) values  ('22003','UCLA'); 
insert into AcademicInstitution(userid,institution) values  ('22003','Yale'); 
insert into AcademicInstitution(userid,institution) values  ('22004','Upenn'); 
insert into AcademicInstitution(userid,institution) values  ('22005','MIT'); 
insert into AcademicInstitution(userid,institution) values  ('22006','NID'); 
insert into AcademicInstitution(userid,institution) values  ('22007','NYU'); 
insert into AcademicInstitution(userid,institution) values  ('22008','Upenn'); 
insert into AcademicInstitution(userid,institution) values  ('22009','BU'); 
insert into AcademicInstitution(userid,institution) values  ('22010','Upenn'); 
insert into AcademicInstitution(userid,institution) values  ('22010','UCSD'); 
insert into AcademicInstitution(userid,institution) values  ('22011','UMass'); 
insert into AcademicInstitution(userid,institution) values  ('22012','UTA'); 
insert into AcademicInstitution(userid,institution) values  ('22012','UCB'); 
insert into AcademicInstitution(userid,institution) values  ('22013','CMU'); 
insert into AcademicInstitution(userid,institution) values  ('22014','Columbia'); 
insert into AcademicInstitution(userid,institution) values  ('22014','Vtech'); 
insert into AcademicInstitution(userid,institution) values  ('22015','UNH'); 
insert into AcademicInstitution(userid,institution) values  ('22016','MU'); 
insert into AcademicInstitution(userid,institution) values  ('22017','VIT'); 
insert into AcademicInstitution(userid,institution) values  ('22018','Oxford'); 
insert into AcademicInstitution(userid,institution) values  ('22019','IIT'); 

#PHOTOS
insert into Photo(pid,userid,url,privacy) values  ('22000','22000','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=200','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22001','22000','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=201','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22002','22000','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=202','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22004','22001','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=203','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22005','22001','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=204','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22006','22001','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=205','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22007','22002','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=206','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22008','22002','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=207','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22009','22002','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=208','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22010','22003','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=209','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22011','22003','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=210','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22012','22003','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=211','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22013','22004','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=212','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22014','22004','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=213','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22015','22004','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=214','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22016','22005','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=215','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22017','22005','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=216','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22018','22005','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=217','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22019','22006','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=218','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22020','22006','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=219','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22021','22006','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=220','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22022','22007','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=221','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22023','22007','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=222','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22024','22007','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=223','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22025','22008','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=224','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22026','22008','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=225','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22027','22008','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=226','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22028','22009','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=227','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22029','22009','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=228','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22030','22009','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=229','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22031','22010','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=230','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22032','22010','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=231','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22033','22010','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=232','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22034','22011','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=233','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22035','22011','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=234','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22036','22011','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=235','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22037','22012','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=236','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22038','22012','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=237','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22039','22012','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=238','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22040','22013','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=239','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22041','22013','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=240','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22042','22013','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=241','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22043','22014','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=242','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22044','22014','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=243','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22045','22014','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=244','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22046','22015','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=245','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22047','22015','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=246','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22048','22015','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=247','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22049','22016','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=248','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22050','22016','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=249','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22051','22016','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=250','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22052','22017','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=251','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22053','22017','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=252','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22054','22017','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=253','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22055','22018','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=254','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22056','22018','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=255','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22057','22018','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=256','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22058','22019','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=257','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22059','22019','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=258','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('22060','22019','http://image.just-download.com/img/data_images/2011/05/16/1305541956-link-shell-extension1.png?w=259','CUSTOM'); 

#RATING
insert into Rating(pid,userid,score) values  ('22000','22001','1'); 
insert into Rating(pid,userid,score) values  ('22001','22001','3'); 
insert into Rating(pid,userid,score) values  ('22002','22004','5'); 
insert into Rating(pid,userid,score) values  ('22004','22000','1'); 
insert into Rating(pid,userid,score) values  ('22005','22002','3'); 
insert into Rating(pid,userid,score) values  ('22006','22004','5'); 
insert into Rating(pid,userid,score) values  ('22007','22001','1'); 
insert into Rating(pid,userid,score) values  ('22008','22001','3'); 
insert into Rating(pid,userid,score) values  ('22009','22000','5'); 
insert into Rating(pid,userid,score) values  ('22010','22002','1'); 
insert into Rating(pid,userid,score) values  ('22011','22001','3'); 
insert into Rating(pid,userid,score) values  ('22012','22002','3'); 
insert into Rating(pid,userid,score) values  ('22013','22003','1'); 
insert into Rating(pid,userid,score) values  ('22014','22001','5'); 
insert into Rating(pid,userid,score) values  ('22015','22003','1'); 
insert into Rating(pid,userid,score) values  ('22016','22007','1'); 
insert into Rating(pid,userid,score) values  ('22017','22006','4'); 
insert into Rating(pid,userid,score) values  ('22018','22009','2'); 
insert into Rating(pid,userid,score) values  ('22019','22009','1'); 
insert into Rating(pid,userid,score) values  ('22020','22008','3'); 
insert into Rating(pid,userid,score) values  ('22021','22005','1'); 
insert into Rating(pid,userid,score) values  ('22022','22006','1'); 
insert into Rating(pid,userid,score) values  ('22023','22005','1'); 
insert into Rating(pid,userid,score) values  ('22024','22008','5'); 
insert into Rating(pid,userid,score) values  ('22025','22006','1'); 
insert into Rating(pid,userid,score) values  ('22026','22005','4'); 
insert into Rating(pid,userid,score) values  ('22027','22006','1'); 
insert into Rating(pid,userid,score) values  ('22028','22010','1'); 
insert into Rating(pid,userid,score) values  ('22029','22005','3'); 
insert into Rating(pid,userid,score) values  ('22030','22006','2'); 
insert into Rating(pid,userid,score) values  ('22031','22011','1'); 
insert into Rating(pid,userid,score) values  ('22032','22014','1'); 
insert into Rating(pid,userid,score) values  ('22033','22012','1'); 
insert into Rating(pid,userid,score) values  ('22034','22014','1'); 
insert into Rating(pid,userid,score) values  ('22035','22010','5'); 
insert into Rating(pid,userid,score) values  ('22036','22012','1'); 
insert into Rating(pid,userid,score) values  ('22037','22014','1'); 
insert into Rating(pid,userid,score) values  ('22038','22013','1'); 
insert into Rating(pid,userid,score) values  ('22039','22010','4'); 
insert into Rating(pid,userid,score) values  ('22040','22011','1'); 
insert into Rating(pid,userid,score) values  ('22041','22012','3'); 
insert into Rating(pid,userid,score) values  ('22042','22011','1'); 
insert into Rating(pid,userid,score) values  ('22043','22015','1'); 
insert into Rating(pid,userid,score) values  ('22044','22013','2'); 
insert into Rating(pid,userid,score) values  ('22045','22015','1'); 
insert into Rating(pid,userid,score) values  ('22046','22016','1'); 
insert into Rating(pid,userid,score) values  ('22047','22019','1'); 
insert into Rating(pid,userid,score) values  ('22048','22016','4'); 
insert into Rating(pid,userid,score) values  ('22049','22015','1'); 
insert into Rating(pid,userid,score) values  ('22050','22019','1'); 
insert into Rating(pid,userid,score) values  ('22051','22018','3'); 
insert into Rating(pid,userid,score) values  ('22052','22016','1'); 
insert into Rating(pid,userid,score) values  ('22053','22019','5'); 
insert into Rating(pid,userid,score) values  ('22054','22018','3'); 
insert into Rating(pid,userid,score) values  ('22055','22016','1'); 
insert into Rating(pid,userid,score) values  ('22056','22015','1'); 
insert into Rating(pid,userid,score) values  ('22057','22016','4'); 
insert into Rating(pid,userid,score) values  ('22058','22017','1'); 
insert into Rating(pid,userid,score) values  ('22059','22018','1'); 
insert into Rating(pid,userid,score) values  ('22060','22016','5'); 

#TAG
insert into Tag(pid,userid,comments) values  ('22000','22001','bad'); 
insert into Tag(pid,userid,comments) values  ('22001','22001','Nice'); 
insert into Tag(pid,userid,comments) values  ('22002','22004','Superb'); 
insert into Tag(pid,userid,comments) values  ('22004','22000','bad'); 
insert into Tag(pid,userid,comments) values  ('22005','22002','nice'); 
insert into Tag(pid,userid,comments) values  ('22006','22004','superb'); 
insert into Tag(pid,userid,comments) values  ('22007','22001','bad'); 
insert into Tag(pid,userid,comments) values  ('22008','22001','nice'); 
insert into Tag(pid,userid,comments) values  ('22009','22000','superb'); 
insert into Tag(pid,userid,comments) values  ('22010','22002','bad'); 
insert into Tag(pid,userid,comments) values  ('22011','22001','nice'); 
insert into Tag(pid,userid,comments) values  ('22012','22002','good'); 
insert into Tag(pid,userid,comments) values  ('22013','22003','bad'); 
insert into Tag(pid,userid,comments) values  ('22014','22001','superb'); 
insert into Tag(pid,userid,comments) values  ('22015','22003','bad'); 
insert into Tag(pid,userid,comments) values  ('22016','22007','bad'); 
insert into Tag(pid,userid,comments) values  ('22017','22006','nice'); 
insert into Tag(pid,userid,comments) values  ('22018','22009','fine'); 
insert into Tag(pid,userid,comments) values  ('22019','22009','bad'); 
insert into Tag(pid,userid,comments) values  ('22020','22008','good'); 
insert into Tag(pid,userid,comments) values  ('22021','22005','bad'); 
insert into Tag(pid,userid,comments) values  ('22022','22006','bad'); 
insert into Tag(pid,userid,comments) values  ('22023','22005','bad'); 
insert into Tag(pid,userid,comments) values  ('22024','22008','superb'); 
insert into Tag(pid,userid,comments) values  ('22025','22006','bad'); 
insert into Tag(pid,userid,comments) values  ('22026','22005','nice'); 
insert into Tag(pid,userid,comments) values  ('22027','22006','bad'); 
insert into Tag(pid,userid,comments) values  ('22028','22010','bad'); 
insert into Tag(pid,userid,comments) values  ('22029','22005','good'); 
insert into Tag(pid,userid,comments) values  ('22030','22006','bad'); 
insert into Tag(pid,userid,comments) values  ('22031','22011','bad'); 
insert into Tag(pid,userid,comments) values  ('22032','22014','bad'); 
insert into Tag(pid,userid,comments) values  ('22033','22012','bad'); 
insert into Tag(pid,userid,comments) values  ('22034','22014','bad'); 
insert into Tag(pid,userid,comments) values  ('22035','22010','excellent'); 
insert into Tag(pid,userid,comments) values  ('22036','22012','bad'); 
insert into Tag(pid,userid,comments) values  ('22037','22014','bad'); 
insert into Tag(pid,userid,comments) values  ('22038','22013','bad'); 
insert into Tag(pid,userid,comments) values  ('22039','22010','superb'); 
insert into Tag(pid,userid,comments) values  ('22040','22011','bad'); 
insert into Tag(pid,userid,comments) values  ('22041','22012','good'); 
insert into Tag(pid,userid,comments) values  ('22042','22011','bad'); 
insert into Tag(pid,userid,comments) values  ('22043','22015','bad'); 
insert into Tag(pid,userid,comments) values  ('22044','22013','not bad'); 
insert into Tag(pid,userid,comments) values  ('22045','22015','bad'); 
insert into Tag(pid,userid,comments) values  ('22046','22016','bad'); 
insert into Tag(pid,userid,comments) values  ('22047','22019','bad'); 
insert into Tag(pid,userid,comments) values  ('22048','22016','good'); 
insert into Tag(pid,userid,comments) values  ('22049','22015','bad'); 
insert into Tag(pid,userid,comments) values  ('22050','22019','bad'); 
insert into Tag(pid,userid,comments) values  ('22051','22018','nice'); 
insert into Tag(pid,userid,comments) values  ('22052','22016','bad'); 
insert into Tag(pid,userid,comments) values  ('22053','22019','excellent'); 
insert into Tag(pid,userid,comments) values  ('22054','22018','god'); 
insert into Tag(pid,userid,comments) values  ('22055','22016','bad'); 
insert into Tag(pid,userid,comments) values  ('22056','22015','bad'); 
insert into Tag(pid,userid,comments) values  ('22057','22016','good enough'); 
insert into Tag(pid,userid,comments) values  ('22058','22017','bad'); 
insert into Tag(pid,userid,comments) values  ('22059','22018','bad'); 
insert into Tag(pid,userid,comments) values  ('22060','22016','superb'); 

#CIRCLEPRIVACY
insert into CirclePrivacy(pid,cid) values  ('22001','22001
	'); 
insert into CirclePrivacy(pid,cid) values  ('22001','22000
	'); 
insert into CirclePrivacy(pid,cid) values  ('22005','22003
	'); 
insert into CirclePrivacy(pid,cid) values  ('22008','22006
	'); 
insert into CirclePrivacy(pid,cid) values  ('22011','22009
	'); 
insert into CirclePrivacy(pid,cid) values  ('22014','22012
	'); 
insert into CirclePrivacy(pid,cid) values  ('22017','22015
	'); 
insert into CirclePrivacy(pid,cid) values  ('22020','22018
	'); 
insert into CirclePrivacy(pid,cid) values  ('22023','22022
	'); 
insert into CirclePrivacy(pid,cid) values  ('22026','22024
	'); 
insert into CirclePrivacy(pid,cid) values  ('22029','22027
	'); 
insert into CirclePrivacy(pid,cid) values  ('22032','22031
	'); 
insert into CirclePrivacy(pid,cid) values  ('22035','22034
	'); 
insert into CirclePrivacy(pid,cid) values  ('22038','22037
	'); 
insert into CirclePrivacy(pid,cid) values  ('22041','22040
	'); 
insert into CirclePrivacy(pid,cid) values  ('22044','22043
	'); 
insert into CirclePrivacy(pid,cid) values  ('22047','22046
	'); 
insert into CirclePrivacy(pid,cid) values  ('22050','22048
	'); 
insert into CirclePrivacy(pid,cid) values  ('22053','22050
	'); 
insert into CirclePrivacy(pid,cid) values  ('22056','22053
	'); 
insert into CirclePrivacy(pid,cid) values  ('22059','22054
	'); 

#USERPRIVACY
insert into UserPrivacy(pid,userid) values  ('22000','22001
	'); 
insert into UserPrivacy(pid,userid) values  ('22000','22004
	'); 
insert into UserPrivacy(pid,userid) values  ('22004','22000
	'); 
insert into UserPrivacy(pid,userid) values  ('22007','22001
	'); 
insert into UserPrivacy(pid,userid) values  ('22010','22002
	'); 
insert into UserPrivacy(pid,userid) values  ('22013','22003
	'); 
insert into UserPrivacy(pid,userid) values  ('22016','22007
	'); 
insert into UserPrivacy(pid,userid) values  ('22019','22009
	'); 
insert into UserPrivacy(pid,userid) values  ('22022','22006
	'); 
insert into UserPrivacy(pid,userid) values  ('22025','22006
	'); 
insert into UserPrivacy(pid,userid) values  ('22028','22010
	'); 
insert into UserPrivacy(pid,userid) values  ('22031','22011
	'); 
insert into UserPrivacy(pid,userid) values  ('22034','22014
	'); 
insert into UserPrivacy(pid,userid) values  ('22037','22014
	'); 
insert into UserPrivacy(pid,userid) values  ('22040','22011
	'); 
insert into UserPrivacy(pid,userid) values  ('22043','22015
	'); 
insert into UserPrivacy(pid,userid) values  ('22046','22016
	'); 
insert into UserPrivacy(pid,userid) values  ('22049','22015
	'); 
insert into UserPrivacy(pid,userid) values  ('22052','22016
	'); 
insert into UserPrivacy(pid,userid) values  ('22055','22016
	'); 
insert into UserPrivacy(pid,userid) values  ('22058','22017
	'); 
