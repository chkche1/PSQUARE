
#USERS
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18001','Mingyu','Liu',null,'mingyu.liu@upenn.edu','M',null,'yu'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18002','Shi','He',null,'shi.he@upenn.edu','F',null,'shi'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18003','Jingwen','Yang',null,'jingwen.yang@upenn.edu','F',null,'wen'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18004','Chao','Zhang',null,'chao.zhang@upenn.edu','M',null,'chao'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18006','Zhepeng','Yan',null,'zhepeng.yan@upenn.edu','M',null,'peng'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18012','Michael','Jordan',null,'michael.jordan@upenn.edu','M',null,'jeffrey'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18013','Condoleezza','Rice',null,'condoleezza.rice@upenn.edu','F',null,'leezza'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18014','George','Bush',null,'george.bush@upenn.edu','M',null,'walker'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18015','John','McCain',null,'john.mccain@upenn.edu','M',null,'sidney'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18016','Sarah','Palin',null,'sarah.palin@upenn.edu','F',null,'louise'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18017','Mark','Zuckerberg',null,'mark.zuckerberg@upenn.edu','M',null,'elliot'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18018','William','Gates',null,'bill.gates@upenn.edu','F',null,'henry'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18019','Steve','Jobs',null,'steve.jobs@upenn.edu','M',null,'job'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18020','Larry','Page',null,'larry.page@upenn.edu','M',null,'arry'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18005','Zachary','Ives',null,'zachary.ives@upenn.edu','M',null,'ary'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18007','Barack','Obama',null,'barack.obama@upenn.edu','M',null,'bama'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18008','Hillary','Clinton',null,'hillary.clinton@upenn.edu','F',null,'lary'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18009','Joseph','Biden',null,'joe.biden@upenn.edu','M',null,'robinette'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18010','John','Kennedy',null,'john.kennedy@upenn.edu','M',null,'jack'); 
insert into Users(userid, first_name, last_name, dob, email, gender, address, password) values  ('18011','Dwight','Eisenhower',null,'dwight.eisenhower@upenn.edu','M',null,'right'); 

#PROFESSORS
insert into Professor(userid, research_area, room_id) values  ('18005','DB','101'); 
insert into Professor(userid, research_area, room_id) values  ('18007','AI','102'); 
insert into Professor(userid, research_area, room_id) values  ('18008','AI','103'); 
insert into Professor(userid, research_area, room_id) values  ('18009','DB','104'); 
insert into Professor(userid, research_area, room_id) values  ('18010','DB','105'); 
insert into Professor(userid, research_area, room_id) values  ('18011','ML','106'); 

#STUDENTS
insert into Student(userid, advisorid, year) values  ('18001','18005',null); 
insert into Student(userid, advisorid, year) values  ('18002','18005',null); 
insert into Student(userid, advisorid, year) values  ('18003','18005',null); 
insert into Student(userid, advisorid, year) values  ('18004','18005',null); 
insert into Student(userid, advisorid, year) values  ('18006','18005',null); 
insert into Student(userid, advisorid, year) values  ('18012','18007',null); 
insert into Student(userid, advisorid, year) values  ('18013','18008',null); 
insert into Student(userid, advisorid, year) values  ('18014','18008',null); 
insert into Student(userid, advisorid, year) values  ('18015','18009',null); 
insert into Student(userid, advisorid, year) values  ('18016','18010',null); 
insert into Student(userid, advisorid, year) values  ('18017','18010',null); 
insert into Student(userid, advisorid, year) values  ('18018','18010',null); 
insert into Student(userid, advisorid, year) values  ('18019','18011',null); 
insert into Student(userid, advisorid, year) values  ('18020','18011',null); 

#CIRCLES
insert into Circle(cid, userid, name) values  ('180013594','18001','Friends'); 
insert into Circle(cid, userid, name) values  ('180023594','18002','Friends'); 
insert into Circle(cid, userid, name) values  ('180033594','18003','Friends'); 
insert into Circle(cid, userid, name) values  ('180043594','18004','Friends'); 
insert into Circle(cid, userid, name) values  ('180053594','18005','Friends'); 

#FRIENDS
insert into FriendRelation(friendid, cid) values  ('18002','180013594'); 
insert into FriendRelation(friendid, cid) values  ('18003','180013594'); 
insert into FriendRelation(friendid, cid) values  ('18004','180013594'); 
insert into FriendRelation(friendid, cid) values  ('18005','180013594'); 
insert into FriendRelation(friendid, cid) values  ('18007','180023594'); 
insert into FriendRelation(friendid, cid) values  ('18008','180023594'); 
insert into FriendRelation(friendid, cid) values  ('18009','180023594'); 
insert into FriendRelation(friendid, cid) values  ('18010','180023594'); 
insert into FriendRelation(friendid, cid) values  ('18011','180023594'); 
insert into FriendRelation(friendid, cid) values  ('18012','180033594'); 
insert into FriendRelation(friendid, cid) values  ('18013','180033594'); 
insert into FriendRelation(friendid, cid) values  ('18014','180043594'); 
insert into FriendRelation(friendid, cid) values  ('18015','180043594'); 
insert into FriendRelation(friendid, cid) values  ('18016','180053594'); 
insert into FriendRelation(friendid, cid) values  ('18017','180053594'); 
insert into FriendRelation(friendid, cid) values  ('18018','180053594'); 

#INTERESTS

#SCHOOLS
insert into AcademicInstitution(userid,institution) values  ('18001','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18002','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18003','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18004','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18006','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18012','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18013','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18014','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18015','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18016','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18017','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18018','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18019','Penn'); 
insert into AcademicInstitution(userid,institution) values  ('18020','Penn'); 

#PHOTOS
insert into Photo(pid,userid,url,privacy) values  ('1','18001','http://upload.wikimedia.org/wikipedia/commons/4/4c/Asian_elephant_-_melbourne_zoo.jpg','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('2','18001','http://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Young_Maasai_Giraffes.jpg/200px-Young_Maasai_Giraffes.jpg','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('3','18002','http://upload.wikimedia.org/wikipedia/commons/f/f3/Loxodontacyclotis.jpg','CUSTOM'); 
insert into Photo(pid,userid,url,privacy) values  ('4','18003','http://upload.wikimedia.org/wikipedia/commons/3/34/Indian_Palm_Squirrel_Portrait.jpg','CUSTOM'); 

#RATING
insert into Rating(pid,userid,score) values  ('1','18019','8'); 
insert into Rating(pid,userid,score) values  ('1','18020','10'); 
insert into Rating(pid,userid,score) values  ('2','18020','9'); 

#TAG
insert into Tag(pid,userid,comments) values  ('1','18020','Animal'); 
insert into Tag(pid,userid,comments) values  ('2','18019','Animal'); 

#CIRCLEPRIVACY

#USERPRIVACY
insert into UserPrivacy(pid,userid) values  ('4','18001'); 
insert into UserPrivacy(pid,userid) values  ('4','18002'); 
insert into UserPrivacy(pid,userid) values  ('1','18002'); 
insert into UserPrivacy(pid,userid) values  ('4','18003'); 
insert into UserPrivacy(pid,userid) values  ('1','18003'); 
insert into UserPrivacy(pid,userid) values  ('4','18004'); 
insert into UserPrivacy(pid,userid) values  ('1','18004'); 
insert into UserPrivacy(pid,userid) values  ('4','18006'); 
insert into UserPrivacy(pid,userid) values  ('4','18012'); 
insert into UserPrivacy(pid,userid) values  ('1','18012'); 
insert into UserPrivacy(pid,userid) values  ('4','18013'); 
insert into UserPrivacy(pid,userid) values  ('1','18013'); 
insert into UserPrivacy(pid,userid) values  ('4','18014'); 
insert into UserPrivacy(pid,userid) values  ('1','18014'); 
insert into UserPrivacy(pid,userid) values  ('2','18014'); 
insert into UserPrivacy(pid,userid) values  ('4','18015'); 
insert into UserPrivacy(pid,userid) values  ('2','18015'); 
insert into UserPrivacy(pid,userid) values  ('4','18016'); 
insert into UserPrivacy(pid,userid) values  ('4','18017'); 
insert into UserPrivacy(pid,userid) values  ('4','18018'); 
insert into UserPrivacy(pid,userid) values  ('3','18018'); 
insert into UserPrivacy(pid,userid) values  ('4','18019'); 
insert into UserPrivacy(pid,userid) values  ('4','18020'); 
insert into UserPrivacy(pid,userid) values  ('4','18005'); 
insert into UserPrivacy(pid,userid) values  ('1','18005'); 
insert into UserPrivacy(pid,userid) values  ('4','18007'); 
insert into UserPrivacy(pid,userid) values  ('2','18007'); 
insert into UserPrivacy(pid,userid) values  ('4','18008'); 
insert into UserPrivacy(pid,userid) values  ('2','18008'); 
insert into UserPrivacy(pid,userid) values  ('4','18009'); 
insert into UserPrivacy(pid,userid) values  ('2','18009'); 
insert into UserPrivacy(pid,userid) values  ('4','18010'); 
insert into UserPrivacy(pid,userid) values  ('2','18010'); 
insert into UserPrivacy(pid,userid) values  ('4','18011'); 
insert into UserPrivacy(pid,userid) values  ('2','18011'); 
